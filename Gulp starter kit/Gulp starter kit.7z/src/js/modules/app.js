class App {
	constructor() {
		console.info('App Initialized');
	}
}

export default App;